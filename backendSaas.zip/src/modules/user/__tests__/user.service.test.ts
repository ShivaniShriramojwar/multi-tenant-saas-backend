import { getUserProfileService } from "../user.service";
import { getUserById } from "../user.repository";

jest.mock("../user.repository");

describe("getUserProfileService", () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it("should return user profile", async () => {
    const mockUser = {
      _id: "123",
      name: "Shivani",
      email: "shivani@test.com",
      role: "admin",
    };

    (getUserById as jest.Mock).mockResolvedValue(mockUser);

    const result = await getUserProfileService("123");

    expect(result).toEqual({
      id: "123",
      name: "Shivani",
      email: "shivani@test.com",
      role: "admin",
      tenant: {
        id: "",
        name: undefined,
      },
    });
  });

  it("should throw error when user not found", async () => {
    (getUserById as jest.Mock).mockResolvedValue(null);

    await expect(getUserProfileService("123")).rejects.toThrow(
      "User not found",
    );
  });
});
